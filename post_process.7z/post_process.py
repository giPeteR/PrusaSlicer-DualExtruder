#!/usr/bin/python

# "C:\Program Files\PrusaSlicer\prusa-slicer-console.exe" --loglevel=4
# python \\3d-computer\c\Peter\3D_printer\Post_process\post_process.py C:\Temp\WinTemp\
# "C:\Program Files\Python\python.exe" \\3d-computer\c\Peter\3D_printer\Post_process\post_process.py

print('\n\n===Post process===\n')

import sys
import re
import os
from datetime import datetime

global logg
global tools
global first_toolchange_extra_restart
global initial_tool
global next_extruder
global deretract_speed
global retract_speed
global retract_length_toolchang
global retract_restart_extra_toolchang

global toolchange_count
toolchange_count = 0

# Init values to something not found in the g-code:
tools = -2
first_toolchange_extra_restart = -2
initial_tool = -2
next_extruder = -2
retract_speed = -2
deretract_speed = -2
retract_length_toolchange = -2
retract_restart_extra_toolchange = -2


def findVals(txt, row):
	rr = re.findall(r"[-+]?[.]?[\d]+(?:,\d\d\d)*[\.]?\d*(?:[eE][-+]?\d+)?", txt)
	i = []
	for s in rr:
		t = re.findall(r"\.", s)
		if t:
			i.append(float(s))
		else:
			i.append(int(s))
	if len(i) == 0:
		print('\nERROR => Row: ', row, ' - Txt: ', txt, '  Vals: >>', i, '<<\n')
		i = -2
	else:
		i = i[0]
		print('Row: ', row, ' - Txt: ', txt, '  Vals: >>', i, '<<')
	return i



# datetime object containing current date and time
now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

#destFile = re.sub(r'\.gcode$','',sourceFile)
sourceFile = sys.argv[1]
print('\n===Source: ', sourceFile, '===\n')


#logg = open("C:\\temp\\py.log", "w")
#logg.write('---Post_Process log---\n')
#logg.write(now)
#logg.write('\n\n')
#logg.write('Source:      {0}\n'.format(sourceFile))


# Read the ENTIRE g-code file into memory
with open(sourceFile, "r") as f:
	lines = f.readlines()
f.close()

#os.rename(sourceFile, sourceFile + '.in.gcode')		# Rename the file before writing a new one (with the same name).

#with open(sourceFile + 'out.gcode', "w") as of:
with open(sourceFile, "w") as of:
	for row in range(len(lines)):
		oline = lines[row]

		of.write(oline) 		# Write original line

		if (toolchange_count == 0) :
			# Parse gcode line
			parts = oline.split(';', 1)
			#print('\n[{0}]'.format(row, "%05,d"), ' = ', oline)

			# The first section can find commands before ';'
			if 0:					# ... but not used here.
			#if len(parts) > 0:
				# Parse command
				txt = parts[0].strip()
				#print('txt: ', txt)
				
				if txt:
					#print('Vals: ', findVals(txt, row))
					sMatch = re.search ('INIT_TOOL (.*)', txt)
					if sMatch:
						# Insert code to bump fan to max before fan speed commands
						of.write('myFanControl-----M106 S255\n')

			# The next section can find comments after ';'
			if len(parts) > 1 and (tools != 1): 	# Don't do anything if tools# = 1, only One tool.
				txt = parts[1].strip()
				#print('#txt: ', txt)
				
				if txt:
					if (tools == -2):
						sMatch = re.findall ('TOOLS', txt)
						if sMatch:
							tools = findVals(txt, row)

					if (first_toolchange_extra_restart == -2):
						sMatch = re.findall ('FIRST_TOOLCHANGE_EXTRA_RESTART', txt)
						if sMatch:
							first_toolchange_extra_restart = findVals(txt, row)

					if (retract_length_toolchange == -2):
						sMatch = re.findall ('RETRACT_LENGTH_TOOLCHANGE', txt)
						if sMatch:
							retract_length_toolchange = findVals(txt, row)

					if (retract_restart_extra_toolchange == -2):
						sMatch = re.findall ('RETRACT_RESTART_EXTRA_TOOLCHANGE', txt)
						if sMatch:
							retract_restart_extra_toolchange = findVals(txt, row)

					if (retract_speed == -2):
						sMatch = re.findall ('RETRACT_SPEED', txt)
						if sMatch:
							retract_speed = findVals(txt, row)

					if (deretract_speed == -2):
						sMatch = re.findall ('DERETRACT_SPEED', txt)
						if sMatch:
							deretract_speed = findVals(txt, row)

					if (toolchange_count == 0):
						sMatch = re.findall ('INITIAL_TOOL', txt)
						if sMatch:
							initial_tool = findVals(txt, row)

					if (toolchange_count == 0):
						sMatch = re.findall ('NEXT_EXTRUDER', txt)
						if sMatch:
							next_extruder = findVals(txt, row)

					# When NEXT_EXTRUDER != INITIAL_TOOL, then we have the first use of the next tool.
					if (next_extruder != initial_tool) and (next_extruder != -2) and (initial_tool != -2) and (toolchange_count == 0):
						toolchange_count = 1
						if deretract_speed == 0:
							deretract_speed = retract_speed
						s = 'T' + str(next_extruder) + ' ; Do the one time UnRetract for the tool that has not been used until now.\n'
						of.write(s)
						of.write('G0 X-7 Y30 F5000 ; Move to wait position off table and purge next tool.\n')
						of.write('G92 E0 ; Zero extruders\n')
						s = 'G1 E' + str(retract_length_toolchange + retract_restart_extra_toolchange + first_toolchange_extra_restart)
						s = s + ' F' + str(deretract_speed) + ' ; UnRetract\n'
						of.write(s)
of.close()



